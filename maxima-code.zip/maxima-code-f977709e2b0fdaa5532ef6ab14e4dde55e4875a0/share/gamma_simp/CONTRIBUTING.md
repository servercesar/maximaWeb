If you have a suggestion or a feature request, please communicate it on the Maxima mailing list. For a patch to the code, please create a new branch, commit changes 
there and create a pull request to the main branch.
