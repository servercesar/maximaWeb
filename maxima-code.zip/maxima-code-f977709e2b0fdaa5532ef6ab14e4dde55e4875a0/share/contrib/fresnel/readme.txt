This directory contains some files I created for Fresnel integrals
and a study of a linear filter driven by a chirp.
Dan Stanger
