# -*-mode: text; fill-column: 75; tab-width: 8; coding: iso-latin-1-unix -*-
#
#	$Id: Readme.txt,v 1.1 2002-09-24 00:46:25 mikeclarkson Exp $
#


For the documentation on EMaxima, see

	../../../doc/emaxima/


